const SETTINGS = {
  CALENDLY_URL: "https://calendly.com/your-link/20min",
  STRIPE_AUDIT_URL: "#",
  STRIPE_URGENCE_URL: "#",
  EMAIL_CONTACT: "contact@letheaegis.com",
  FORMSPREE_ENDPOINT: ""
};

const i18n = {
  fr: {
    brandName: "Lethe Aegis",
    brandTag: "Anonymat & Réputation",
    claim: "Nous effaçons vos traces avant qu'elles ne deviennent vos chaînes.",
    subclaim: "Légal. Rapide. Discret. Traçable.",
    nav: { home:"Accueil", services:"Offres & Prix", process:"Méthode", cases:"Cas", faq:"FAQ", contact:"Contact", legal:"Mentions & Privacy", lang:"EN" },
    hero: {
      heading: "Votre bouclier invisible en ligne",
      subheading: "Protection d'anonymat et réputation, exécution rapide, preuves livrables.",
      ctaCall: "Réserver un appel 20 min",
      ctaAudit: "Audit Express 500€",
      ctaUrgence: "Urgence 72h — 1 200€"
    },
    painSolution: {
      title: "Votre douleur, notre terrain de jeu",
      pains: [
        { t:"Fuites de contenus (leaks)", d:"Perte de revenus, diffusion non autorisée de contenus payants." },
        { t:"Impersonation & catfish", d:"Usurpation d'identité, comptes frauduleux qui diluent votre marque." },
        { t:"Déréférencement RGPD", d:"Résultats nuisibles ou obsolètes; droit à l'oubli (Art. 17) si éligible." },
        { t:"Doxxing & exposition", d:"Données sensibles exposées; réduction immédiate de la surface d'attaque." }
      ],
      solutionIntro: "Lethe Aegis agit légalement et vite, avec reporting traçable et preuves d'exécution."
    },
    process: {
      title: "Méthode en 5 étapes",
      steps: [
        { t:"Intake sécurisé", d:"Brief + vérifications KYC légères, canaux chiffrés." },
        { t:"Preuve de titularité", d:"Captures, dépôts, liens sources; autorisations signées." },
        { t:"Action légale", d:"DMCA/TOS, RGPD/déréférencement, formulaires officiels, emails signés." },
        { t:"Suivi & relances", d:"Calendrier de relance jusqu'à exécution ou fermeture du ticket." },
        { t:"Rapport & prévention", d:"Rapport PDF, tableau de liens, recommandations de cloisonnement." }
      ]
    },
    offers: {
      title: "Offres & Prix",
      audit: {
        name:"Audit Express",
        price:"500€",
        sla:"Livré sous 48h",
        bullets:[
          "Cartographie des URLs problématiques",
          "Plan d'actions priorisé 30 jours",
          "Jusqu'à 2 notifications DMCA si éligible",
          "Rapport PDF (3 pages) + call 20 min"
        ],
        cta:"Commander l'audit"
      },
      retainer: {
        name:"Abonnement (mensuel)",
        tiersTitle:"Paliers",
        tiers:[
          { n:"Essential", p:"2 500€/mois", f:["≤30 URLs/mois","2 plateformes cibles","Rapport hebdo"] },
          { n:"Pro", p:"3 500€/mois", f:["≤60 URLs/mois","4 plateformes","Veille + relances renforcées"] },
          { n:"Elite", p:"5 000€/mois", f:["≤120 URLs/mois","8 plateformes","Prioritaire 24/7 + anti-impersonation"] }
        ],
        note:"Prix HT. Volume 'raisonnable'. Au-delà: devis."
      },
      urgence: {
        name:"Urgence 72h",
        price:"1 200€ (one-shot)",
        sla:"Démarrage immédiat",
        bullets:[
          "Priorisation 72h, fenêtre dédiée",
          "Jusqu'à 20 URLs traitées",
          "Rapport d'exécution + prochaines étapes"
        ],
        cta:"Activer l'urgence"
      },
      legalLimitsTitle:"Limites & Légalité",
      legalLimits:[
        "Aucune promesse de résultat absolu",
        "Zéro hacking / pas de mineurs / pas de doxxing offensif",
        "Action uniquement sur base de preuve et de droit applicable",
        "Conseil de conformité pratique — pas de conseil juridique"
      ]
    },
    cases: {
      title:"Cas anonymisés",
      items:[
        { t:"Créatrice X (Top 1%)", d:"11 liens supprimés en 72h (Reddit, Telegram, 2 index Google FR)", m:"Impact: récupération d'abonnés payants." },
        { t:"Avocat Y (C-level visibilité)", d:"3 résultats toxiques déréférencés en 30 jours (Google FR/BE)", m:"Impact: réputation rétablie, leads préservés." }
      ]
    },
    faq: {
      title:"FAQ anxiolytiques",
      qas:[
        { q:"Combien de temps pour un retrait DMCA ?", a:"24–72h sur plateformes coopératives; 10 jours ouvrés en moyenne pour le reste." },
        { q:"Garantissez-vous 100 % de suppression ?", a:"Non. Engagement de diligence, vitesse et traçabilité; jamais de promesse absolue." },
        { q:"Gérez-vous le droit à l'oubli RGPD ?", a:"Oui: éligibilité (Art.17), dossier, demande de déréférencement et suivi." },
        { q:"Quelles plateformes couvrez-vous ?", a:"Google/Bing, X/Reddit/Instagram/TikTok, hébergeurs/fora, Telegram si coopération." },
        { q:"Comment protégez-vous mes données ?", a:"Minimisation, accès restreint, partage 'need-to-know', suppression sur demande." },
        { q:"Quelles preuves fournissez-vous ?", a:"Captures datées, accusés de réception, tableaux d'état, PDF récapitulatif." },
        { q:"Puis-je résilier ?", a:"Audit: one-shot. Retainer: mensuel, résiliable chaque mois (préavis 7 jours)." },
        { q:"Gérez-vous l'urgence la nuit/week-end ?", a:"Oui pour 'Urgence 72h' (fenêtre prioritaire). Sinon: heures ouvrées." },
        { q:"Quels pays couvrez-vous ?", a:"UE/UK/US/UAE (FR/EN). Méthodes adaptées par juridiction." },
        { q:"Quels moyens de paiement ?", a:"Stripe/CB et PayPal. Facturation HT." }
      ]
    },
    contact: {
      title:"Contact",
      lead:"Parlons sécurité d'image et retrait crédible.",
      emailLabel:"Email",
      nameLabel:"Nom",
      messageLabel:"Message",
      consent:"J'accepte que mes données soient traitées pour répondre à ma demande.",
      send:"Envoyer",
      alt:"Ou écrivez-nous :",
      calendly:"Réserver un appel"
    },
    footer: {
      rights:"© Lethe Aegis. Tous droits réservés.",
      privacy:"Mentions & Privacy",
      phrase:"Nous effaçons vos traces avant qu'elles ne deviennent vos chaînes."
    },
    cookieText: "Ce site utilise des cookies pour améliorer votre expérience.",
    cookieAccept: "Accepter",
    cookieRefuse: "Refuser",
    cookieSettings: "Préférences",
    thanks: {
      title: "Message envoyé avec succès",
      message: "Merci pour votre confiance. Nous traiterons votre demande dans les plus brefs délais et vous recontacterons sous 24-48h ouvrées.",
      urgent: "Pour une urgence, réservez directement un appel.",
      home: "Retour à l'accueil",
      call: "Réserver un appel"
    },
    legal: {
      title: "Mentions légales & Politique de confidentialité",
      back: "Retour à l'accueil",
      mentions: {
        title: "Mentions légales",
        service: "Lethe Aegis est une marque de service spécialisée dans la protection d'anonymat et la gestion de réputation en ligne.",
        contact: "Contact: contact@letheaegis.com",
        territory: "Territoires d'intervention: UE, UK, US, UAE",
        disclaimer: "Nos services sont fournis avec une obligation de moyens, non de résultat. Aucune garantie absolue de suppression ou de déréférencement n'est donnée.",
        legal: "Nous agissons uniquement dans le cadre légal applicable et sur base de preuves vérifiables."
      },
      privacy: {
        title: "Politique de confidentialité",
        data: {
          title: "Données collectées",
          1: "Données d'identification (nom, email) via formulaire de contact",
          2: "Données techniques (IP, navigateur) pour la sécurité",
          3: "Données de navigation si cookies acceptés",
          4: "Contenus et preuves fournis pour l'exécution du service"
        },
        basis: {
          title: "Base légale",
          text: "Consentement explicite (formulaire) ou exécution contractuelle (clients)."
        },
        duration: {
          title: "Durée de conservation",
          1: "Données prospects: 3 ans après dernier contact",
          2: "Données clients: durée contractuelle + 5 ans (obligations légales)",
          3: "Cookies: 13 mois maximum"
        },
        rights: {
          title: "Vos droits RGPD",
          1: "Accès à vos données personnelles",
          2: "Rectification des données inexactes",
          3: "Effacement (droit à l'oubli)",
          4: "Limitation du traitement",
          5: "Portabilité des données",
          6: "Opposition au traitement",
          contact: "Pour exercer vos droits: dpo@letheaegis.com"
        },
        security: {
          title: "Sécurité",
          text: "Nous appliquons des mesures techniques et organisationnelles appropriées: chiffrement, accès restreint, minimisation des données."
        }
      },
      cookies: {
        title: "Politique de cookies",
        types: {
          title: "Types de cookies",
          1: "Essentiels: fonctionnement du site, préférences de langue",
          2: "Analytics: analyse d'audience (désactivés par défaut)"
        },
        manage: {
          title: "Gestion du consentement",
          text: "Les cookies analytics ne sont activés qu'après votre consentement explicite. Vous pouvez modifier vos préférences à tout moment via le bandeau cookies."
        },
        duration: {
          title: "Durée",
          text: "Les cookies ont une durée de vie maximale de 13 mois."
        }
      }
    }
  },
  en: {
    brandName:"Lethe Aegis",
    brandTag:"Anonymity & Reputation",
    claim:"We erase your traces before they become your chains.",
    subclaim:"Legal. Fast. Discreet. Auditable.",
    nav:{ home:"Home", services:"Plans & Pricing", process:"Process", cases:"Cases", faq:"FAQ", contact:"Contact", legal:"Legal & Privacy", lang:"FR" },
    hero:{ heading:"Your invisible shield online", subheading:"Reputation & anonymity, fast execution, auditable proof.", ctaCall:"Book a 20-min call", ctaAudit:"Express Audit €500", ctaUrgence:"72h Urgency — €1,200" },
    painSolution:{
      title:"Your pain, our arena",
      pains:[
        { t:"Leaked paid content", d:"Revenue loss and loss of control over your work." },
        { t:"Impersonation & catfish", d:"Identity abuse, fake accounts diluting your brand." },
        { t:"De-indexing (GDPR)", d:"Harmful/obsolete results; right to erasure (Art.17) if eligible." },
        { t:"Doxxing & exposure", d:"Sensitive data online; immediate attack-surface reduction." }
      ],
      solutionIntro:"Lethe Aegis acts lawfully and fast, with auditable reporting and proof."
    },
    process:{
      title:"5-step method",
      steps:[
        { t:"Secure intake", d:"Brief + light KYC, encrypted channels." },
        { t:"Ownership proof", d:"Screenshots, deposits, sources; signed authorizations." },
        { t:"Legal action", d:"DMCA/TOS, GDPR requests, official forms, signed emails." },
        { t:"Follow-ups", d:"Reminders calendar until execution or closure." },
        { t:"Report & prevention", d:"PDF report, links table, compartmentalization tips." }
      ]
    },
    offers:{
      title:"Plans & Pricing",
      audit:{ name:"Express Audit", price:"€500", sla:"Delivered within 48h", bullets:["Issue links mapping","30-day prioritized action plan","Up to 2 DMCA notices if eligible","PDF report (3 pages) + 20-min call"], cta:"Order the audit" },
      retainer:{
        name:"Monthly Retainer",
        tiersTitle:"Tiers",
        tiers:[
          { n:"Essential", p:"€2,500/mo", f:["≤30 URLs/month","2 target platforms","Weekly report"] },
          { n:"Pro", p:"€3,500/mo", f:["≤60 URLs/month","4 platforms","Monitoring + stronger follow-ups"] },
          { n:"Elite", p:"€5,000/mo", f:["≤120 URLs/month","8 platforms","24/7 priority + anti-impersonation"] }
        ],
        note:"Prices excl. VAT. 'Reasonable' volume. Beyond: custom quote."
      },
      urgence:{ name:"72h Urgency", price:"€1,200 (one-off)", sla:"Immediate start", bullets:["72h prioritization window","Up to 20 URLs processed","Execution report + next steps"], cta:"Activate urgency" },
      legalLimitsTitle:"Limits & Legality",
      legalLimits:[
        "No absolute result guarantees",
        "No hacking / no minors / no offensive doxxing",
        "Action only with proof and applicable law",
        "Practical compliance guidance — not legal advice"
      ]
    },
    cases:{ title:"Anonymized cases", items:[
      { t:"Creator X (Top 1%)", d:"11 links removed in 72h (Reddit, Telegram, 2 Google indexes)", m:"Impact: paid subscriber recovery." },
      { t:"Attorney Y (C-level exposure)", d:"3 toxic SERP items de-listed within 30 days (Google FR/BE)", m:"Impact: reputation restored, leads preserved." }
    ]},
    faq:{ title:"Anxiety-reducing FAQ", qas:[
      { q:"How long for a DMCA removal?", a:"24–72h on cooperative platforms; ~10 business days otherwise." },
      { q:"Do you guarantee 100% removals?", a:"No. We commit to diligence, speed and auditability; never absolute results." },
      { q:"Do you handle GDPR de-listing?", a:"Yes: eligibility (Art.17), file preparation, request and follow-up." },
      { q:"Which platforms are covered?", a:"Google/Bing, X/Reddit/Instagram/TikTok, hosts/forums, Telegram if cooperative." },
      { q:"How is my data protected?", a:"Data minimization, restricted access, need-to-know sharing, deletion on request." },
      { q:"What proof do I receive?", a:"Dated screenshots, acknowledgements, status tables, PDF recap." },
      { q:"Can I cancel?", a:"Audit is one-off. Retainer is monthly, cancellable (7-day notice)." },
      { q:"Do you operate nights/weekends?", a:"Yes for '72h Urgency' (priority window). Else business hours." },
      { q:"Which countries?", a:"EU/UK/US/UAE (FR/EN). Methods adapted per jurisdiction." },
      { q:"Payment methods?", a:"Stripe/cards and PayPal. Prices excl. VAT." }
    ]},
    contact:{ title:"Contact", lead:"Let's talk image security and credible removals.", emailLabel:"Email", nameLabel:"Name", messageLabel:"Message", consent:"I agree to my data being processed to answer my request.", send:"Send", alt:"Or write to:", calendly:"Book a call" },
    footer:{ rights:"© Lethe Aegis. All rights reserved.", privacy:"Legal & Privacy", phrase:"We erase your traces before they become your chains." },
    cookieText: "This site uses cookies to improve your experience.",
    cookieAccept: "Accept",
    cookieRefuse: "Refuse",
    cookieSettings: "Settings",
    thanks: {
      title: "Message sent successfully",
      message: "Thank you for your trust. We will process your request as soon as possible and contact you within 24-48 business hours.",
      urgent: "For urgent matters, book a call directly.",
      home: "Back to home",
      call: "Book a call"
    },
    legal: {
      title: "Legal Notice & Privacy Policy",
      back: "Back to home",
      mentions: {
        title: "Legal Notice",
        service: "Lethe Aegis is a service brand specializing in anonymity protection and online reputation management.",
        contact: "Contact: contact@letheaegis.com",
        territory: "Service territories: EU, UK, US, UAE",
        disclaimer: "Our services are provided with an obligation of means, not results. No absolute guarantee of removal or de-indexing is given.",
        legal: "We act only within the applicable legal framework and based on verifiable evidence."
      },
      privacy: {
        title: "Privacy Policy",
        data: {
          title: "Data collected",
          1: "Identification data (name, email) via contact form",
          2: "Technical data (IP, browser) for security",
          3: "Navigation data if cookies accepted",
          4: "Content and evidence provided for service execution"
        },
        basis: {
          title: "Legal basis",
          text: "Explicit consent (form) or contractual execution (clients)."
        },
        duration: {
          title: "Retention period",
          1: "Prospect data: 3 years after last contact",
          2: "Client data: contract duration + 5 years (legal obligations)",
          3: "Cookies: 13 months maximum"
        },
        rights: {
          title: "Your GDPR rights",
          1: "Access to your personal data",
          2: "Rectification of inaccurate data",
          3: "Erasure (right to be forgotten)",
          4: "Restriction of processing",
          5: "Data portability",
          6: "Opposition to processing",
          contact: "To exercise your rights: dpo@letheaegis.com"
        },
        security: {
          title: "Security",
          text: "We apply appropriate technical and organizational measures: encryption, restricted access, data minimization."
        }
      },
      cookies: {
        title: "Cookie Policy",
        types: {
          title: "Types of cookies",
          1: "Essential: site operation, language preferences",
          2: "Analytics: audience analysis (disabled by default)"
        },
        manage: {
          title: "Consent management",
          text: "Analytics cookies are only activated after your explicit consent. You can modify your preferences at any time via the cookie banner."
        },
        duration: {
          title: "Duration",
          text: "Cookies have a maximum lifespan of 13 months."
        }
      }
    }
  }
};

let currentLang = localStorage.getItem('lang') || 'fr';

function updateContent() {
  document.documentElement.lang = currentLang;
  const elements = document.querySelectorAll('[data-i18n-key]');
  
  elements.forEach(el => {
    const keys = el.getAttribute('data-i18n-key').split('.');
    let value = i18n[currentLang];
    
    for (const key of keys) {
      if (key.includes('[') && key.includes(']')) {
        const [arrayKey, index] = key.split('[');
        value = value[arrayKey][parseInt(index.replace(']', ''))];
      } else {
        value = value ? value[key] : undefined;
      }
    }
    
    if (value) {
      if (typeof value === 'object') {
        if (value.t) el.textContent = value.t;
        if (value.d) el.textContent = value.d;
        if (value.m) el.textContent = value.m;
        if (value.q) el.textContent = value.q;
        if (value.a) el.textContent = value.a;
        if (value.n) el.textContent = value.n;
        if (value.p) el.textContent = value.p;
        if (value.f && Array.isArray(value.f)) {
          el.textContent = value.f.join(', ');
        }
      } else {
        el.textContent = value;
      }
    }
  });
  
  updatePainCards();
  updateProcessSteps();
  updateOffers();
  updateCases();
  updateFAQ();
}

function updatePainCards() {
  const cards = document.querySelectorAll('.pain-card');
  cards.forEach((card, index) => {
    const h3 = card.querySelector('h3');
    const p = card.querySelector('p');
    if (h3) h3.textContent = i18n[currentLang].painSolution.pains[index].t;
    if (p) p.textContent = i18n[currentLang].painSolution.pains[index].d;
  });
}

function updateProcessSteps() {
  const steps = document.querySelectorAll('.process-step');
  steps.forEach((step, index) => {
    const h3 = step.querySelector('h3');
    const p = step.querySelector('p');
    if (h3) h3.textContent = i18n[currentLang].process.steps[index].t;
    if (p) p.textContent = i18n[currentLang].process.steps[index].d;
  });
}

function updateOffers() {
  const auditBullets = document.querySelectorAll('.offer-card:first-child .features li');
  auditBullets.forEach((li, index) => {
    if (i18n[currentLang]?.offers?.audit?.bullets?.[index]) {
      li.textContent = i18n[currentLang].offers.audit.bullets[index];
    }
  });
  
  const urgenceBullets = document.querySelectorAll('.offer-card:nth-child(2) .features li');
  urgenceBullets.forEach((li, index) => {
    if (i18n[currentLang]?.offers?.urgence?.bullets?.[index]) {
      li.textContent = i18n[currentLang].offers.urgence.bullets[index];
    }
  });
  
  const tiers = document.querySelectorAll('.tier');
  tiers.forEach((tier, index) => {
    const h4 = tier.querySelector('h4');
    const price = tier.querySelector('.tier-price');
    const features = tier.querySelectorAll('ul li');
    
    if (i18n[currentLang]?.offers?.retainer?.tiers?.[index]) {
      if (h4) h4.textContent = i18n[currentLang].offers.retainer.tiers[index].n;
      if (price) price.textContent = i18n[currentLang].offers.retainer.tiers[index].p;
      features.forEach((li, fi) => {
        li.textContent = i18n[currentLang].offers.retainer.tiers[index].f[fi];
      });
    }
  });
  
  const limits = document.querySelectorAll('.alert li');
  limits.forEach((li, index) => {
    if (i18n[currentLang]?.offers?.legalLimits?.[index]) {
      li.textContent = i18n[currentLang].offers.legalLimits[index];
    }
  });
}

function updateCases() {
  const cases = document.querySelectorAll('.case-card');
  cases.forEach((card, index) => {
    const h3 = card.querySelector('h3');
    const p = card.querySelector('p:not(.impact)');
    const impact = card.querySelector('.impact');
    
    if (i18n[currentLang]?.cases?.items?.[index]) {
      if (h3) h3.textContent = i18n[currentLang].cases.items[index].t;
      if (p) p.textContent = i18n[currentLang].cases.items[index].d;
      if (impact) impact.textContent = i18n[currentLang].cases.items[index].m;
    }
  });
}

function updateFAQ() {
  const items = document.querySelectorAll('.faq-item');
  items.forEach((item, index) => {
    const summary = item.querySelector('summary');
    const p = item.querySelector('p');
    
    if (i18n[currentLang]?.faq?.qas?.[index]) {
      if (summary) summary.textContent = i18n[currentLang].faq.qas[index].q;
      if (p) p.textContent = i18n[currentLang].faq.qas[index].a;
    }
  });
}

function toggleLanguage() {
  currentLang = currentLang === 'fr' ? 'en' : 'fr';
  localStorage.setItem('lang', currentLang);
  updateContent();
}

document.addEventListener('DOMContentLoaded', () => {
  updateContent();
  
  const langButtons = document.querySelectorAll('#lang-toggle, #lang-toggle-footer');
  langButtons.forEach(btn => {
    btn.addEventListener('click', toggleLanguage);
  });
  
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');
  
  if (navToggle) {
    navToggle.addEventListener('click', () => {
      navMenu.classList.toggle('active');
      navToggle.setAttribute('aria-expanded', navMenu.classList.contains('active'));
    });
  }
  
  const cookieBanner = document.getElementById('cookie-banner');
  const cookieConsent = localStorage.getItem('cookieConsent');
  
  if (!cookieConsent && cookieBanner) {
    setTimeout(() => {
      cookieBanner.classList.add('show');
    }, 1000);
  }
  
  document.getElementById('cookie-accept')?.addEventListener('click', () => {
    localStorage.setItem('cookieConsent', 'accepted');
    cookieBanner.classList.remove('show');
    loadAnalytics();
  });
  
  document.getElementById('cookie-refuse')?.addEventListener('click', () => {
    localStorage.setItem('cookieConsent', 'refused');
    cookieBanner.classList.remove('show');
  });
 
  document.getElementById('cookie-settings')?.addEventListener('click', () => {
    alert(currentLang === 'fr' ? 'Préférences cookies: Analytics désactivés par défaut. Acceptez pour activer.' : 'Cookie preferences: Analytics disabled by default. Accept to enable.');
  });
 
  if (cookieConsent === 'accepted') {
    loadAnalytics();
  }
 
  const calendlyTriggers = document.querySelectorAll('.calendly-trigger');
  const calendlyModal = document.getElementById('calendly-modal');
  const modalClose = document.querySelector('.modal-close');
 
  calendlyTriggers.forEach(trigger => {
    trigger.addEventListener('click', () => {
      if (SETTINGS.CALENDLY_URL && SETTINGS.CALENDLY_URL !== '#') {
        if (calendlyModal) {
          calendlyModal.classList.add('show');
          const embed = document.getElementById('calendly-embed');
          if (embed && !embed.innerHTML) {
            embed.innerHTML = `<iframe src="${SETTINGS.CALENDLY_URL}" width="100%" height="100%" frameborder="0"></iframe>`;
          }
        } else {
          window.open(SETTINGS.CALENDLY_URL, '_blank');
        }
      }
    });
  });
 
  modalClose?.addEventListener('click', () => {
    calendlyModal.classList.remove('show');
  });
 
  calendlyModal?.addEventListener('click', (e) => {
    if (e.target === calendlyModal) {
      calendlyModal.classList.remove('show');
    }
  });
 
  const stripeAuditButtons = document.querySelectorAll('.stripe-audit');
  stripeAuditButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      if (SETTINGS.STRIPE_AUDIT_URL && SETTINGS.STRIPE_AUDIT_URL !== '#') {
        window.open(SETTINGS.STRIPE_AUDIT_URL, '_blank');
      }
    });
  });
 
  const stripeUrgenceButtons = document.querySelectorAll('.stripe-urgence');
  stripeUrgenceButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      if (SETTINGS.STRIPE_URGENCE_URL && SETTINGS.STRIPE_URGENCE_URL !== '#') {
        window.open(SETTINGS.STRIPE_URGENCE_URL, '_blank');
      }
    });
  });
 
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const formData = new FormData(contactForm);
      const data = {
        name: formData.get('name'),
        email: formData.get('email'),
        message: formData.get('message'),
        consent: formData.get('consent') ? true : false
      };
      
      if (!data.consent) {
        alert(currentLang === 'fr' ? 'Veuillez accepter le traitement de vos données.' : 'Please accept data processing.');
        return;
      }
      
      if (SETTINGS.FORMSPREE_ENDPOINT) {
        try {
          const response = await fetch(SETTINGS.FORMSPREE_ENDPOINT, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json'
            },
            body: JSON.stringify(data)
          });
          
          if (response.ok) {
            window.location.href = '/thanks.html';
          } else {
            throw new Error('Form submission failed');
          }
        } catch (error) {
          console.error('Error:', error);
          sendMailto(data);
        }
      } else {
        sendMailto(data);
      }
    });
  }
 
  function sendMailto(data) {
    const subject = encodeURIComponent('Nouvelle demande Lethe Aegis');
    const body = encodeURIComponent(`
Nom: ${data.name}
Email: ${data.email}
Message: ${data.message}
Consentement RGPD: ${data.consent ? 'Oui' : 'Non'}
    `);
    window.location.href = `mailto:${SETTINGS.EMAIL_CONTACT}?subject=${subject}&body=${body}`;
  }
 
  const navLinks = document.querySelectorAll('.nav-menu a[href^="#"]');
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      const href = link.getAttribute('href');
      if (href && href.startsWith('#')) {
        e.preventDefault();
        const target = document.querySelector(href);
        if (target) {
          target.scrollIntoView({ behavior: 'smooth' });
          if (navMenu && navMenu.classList.contains('active')) {
            navMenu.classList.remove('active');
            navToggle?.setAttribute('aria-expanded', 'false');
          }
        }
      }
    });
  });
 
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
  };
 
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, observerOptions);
 
  const animatedElements = document.querySelectorAll('.card, .process-step, .faq-item');
  animatedElements.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(el);
  });
});

function loadAnalytics() {
  console.log('Analytics placeholder loaded - Replace with actual analytics code');
  // Google Analytics or other analytics script would go here
  // Example: gtag('config', 'GA_MEASUREMENT_ID');
}

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    const calendlyModal = document.getElementById('calendly-modal');
    if (calendlyModal && calendlyModal.classList.contains('show')) {
      calendlyModal.classList.remove('show');
    }
  }
});

const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
if (prefersReducedMotion.matches) {
  document.documentElement.style.setProperty('--transition', 'none');
}

if ('serviceWorker' in navigator && window.location.hostname !== 'localhost') {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  });
}
