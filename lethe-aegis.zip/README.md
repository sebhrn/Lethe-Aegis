# Lethe Aegis – Site vitrine statique

## Structure du projet
```
lethe-aegis/
  index.html
  legal.html
  thanks.html
  assets/
    logo.svg
    favicon.svg
    og.png
  css/
    styles.css
  js/
    script.js
  robots.txt
  sitemap.xml
  sw.js
  README.md
```

## Déploiement rapide

### Netlify (drag & drop)
1. Crée un compte sur Netlify
2. *Add new site → Deploy manually* puis glisse le dossier `lethe-aegis/`
3. Ajoute ton domaine dans **Site settings → Domain management** (TLS auto)

### Vercel (import Git ou CLI)
1. `npm i -g vercel`
2. Dans le dossier parent: `vercel --prod`
3. Sélectionne **Static Site** et indique que le dossier à publier est `lethe-aegis`

### Cloudflare Pages
- *Workers & Pages → Create application → Pages → Upload assets* puis dépose `lethe-aegis/`

## Réglages à personnaliser
- Dans `js/script.js`, renseigne:
  - `CALENDLY_URL` (lien de prise de rendez-vous)
  - `FORMSPREE_ENDPOINT` si tu veux un envoi de formulaire sans client mail
  - `STRIPE_AUDIT_URL` et `STRIPE_URGENCE_URL` si paiement en direct
- Remplace `assets/og.png` par ton visuel 1200×630 si besoin.

## SEO
- `sitemap.xml` propre et référencé dans `robots.txt`
- Balises Open Graph/Twitter avec `assets/og.png` (PNG/JPG plutôt que SVG).

## Service Worker
- `sw.js` minimal inclus pour éviter les erreurs de console. Étends-le si tu veux du cache offline.

Bonne mise en ligne !
